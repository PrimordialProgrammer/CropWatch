package com.example.cropwatch_code;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Log.d(TAG, "MainActivity launched");


        Button loginButton = findViewById(R.id.button);


        if (loginButton != null) {
            Log.d(TAG, "Login button found");


            loginButton.setOnClickListener(v -> {

                Log.d(TAG, "Login button clicked");


                Intent intent = new Intent(MainActivity.this, HomePage.class);
                startActivity(intent);  // Navigate to HomePage


                Log.d(TAG, "Navigating to HomePage");
            });
        } else {
            Log.e(TAG, "Login button not found");
        }
    }
}